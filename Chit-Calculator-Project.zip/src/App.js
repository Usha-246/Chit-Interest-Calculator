import React from "react";
import "./Components/App.css"
import Header from "./Components/Header";

function App() {
  return (
    <div>
        
        <Header/>
        
        
    </div>
  );
}

export default App;
