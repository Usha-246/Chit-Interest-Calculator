const handleSubmit = (e)=>{
    let newDisplay = {Interst:'',AmountValues:'',Installment:'',Commission:''}
   e.preventDefault()
  let data1 =  firstIntallment();
  console.log(typeof(data1))
//    data.Interst,data.Installment,data.Commission
//     secondInstallment()
//     let data2 = secondInstallment()
//      let data3 =thirdInstallment()
//         firstIntallment()
//         secondInstallment()
//         thirdInstallment()
//      setDisplay([...display,newDisplay])
//    // console.log(typeof(data3))
//    console.log(newDisplay.AmountValues)
}


console.log(Installment,Commission)
        console.log(typeof(values.commPercent))
        //return {Installment,Commission, Interst}


            Interst:Interst
            AmountVal:AmountVal
            Installment:Installment
            Commission:Commission

            let obj = {Interst,AmountVal,Installment,Commission}
           console.log(obj)
            let arr = [...obj]
            console.log(arr)
            //console.log(Interst,AmountVal,Installment,Commission)
           // return[{...Interst,...AmountVal,...Installment,...Commission}]
            return arr;